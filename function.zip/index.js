const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    let response;
    const body = event.body ? JSON.parse(event.body) : {};

    try {
        switch (event.httpMethod) {
            // Create (POST)
            case 'POST':
                await dynamo.put({
                    TableName: 'FinanceTracker',
                    Item: {
                        transactionId: body.transactionId,
                        type: body.type,
                        amount: body.amount,
                        category: body.category,
                        date: body.date
                    }
                }).promise();
                response = { statusCode: 201, body: JSON.stringify({ message: "Transaction created!" }) };
                break;

            // Read (GET)
            case 'GET':
                const result = await dynamo.scan({ TableName: 'FinanceTracker' }).promise();
                response = { statusCode: 200, body: JSON.stringify(result.Items) };
                break;

            // Update (PUT)
            case 'PUT':
                await dynamo.update({
                    TableName: 'FinanceTracker',
                    Key: { transactionId: body.transactionId },
                    UpdateExpression: "set #type = :type, amount = :amount, category = :category, #date = :date",
                    ExpressionAttributeNames: {
                        "#type": "type",
                        "#date": "date"
                    },
                    ExpressionAttributeValues: {
                        ":type": body.type,
                        ":amount": body.amount,
                        ":category": body.category,
                        ":date": body.date
                    }
                }).promise();
                response = { statusCode: 200, body: JSON.stringify({ message: "Transaction updated!" }) };
                break;

            // Delete (DELETE)
            case 'DELETE':
                await dynamo.delete({
                    TableName: 'FinanceTracker',
                    Key: { transactionId: body.transactionId }
                }).promise();
                response = { statusCode: 200, body: JSON.stringify({ message: "Transaction deleted!" }) };
                break;

            default:
                response = { statusCode: 400, body: JSON.stringify({ message: "Unsupported HTTP method" }) };
        }
    } catch (error) {
        console.error("Error:", error);
        response = { statusCode: 500, body: JSON.stringify({ message: "Internal server error" }) };
    }

    response.headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, GET, PUT, DELETE",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    };
    return response;
};
